package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class HeuristiquePersoTest {

    private HeuristiquePerso heuristiquePerso;
    private List<Temple> temples;
    private Apprenti apprenti;
    private Temple a;
    private Temple b;
    private Temple c;
    private Temple d;
    private List<Temple> l;

    @BeforeEach
    public void setUp() {
        heuristiquePerso = new HeuristiquePerso();
        apprenti = new Apprenti(0, 0);
        a = new Temple(6, 2, 3, 1);
        b = new Temple(1, 1, 1, 2);
        c = new Temple(2, 3, 2, 4);
        d = new Temple(3, 3, 4, 3);

        temples = new ArrayList<>(Arrays.asList(a, b, c, d));
        l = heuristiquePerso.generatePath(temples, apprenti);

    }

    @Test
    public void testGeneratePathNoCrystal() {
        assertEquals(1, l.size());
        assertEquals(b, l.get(0));
    }

    @Test
    public void testGeneratePathWithCrystal() {
        apprenti.setColorCrystal(2);
        l = heuristiquePerso.generatePath(temples, apprenti);
        assertEquals(1, l.size());
        assertEquals(c, l.get(0));
    }

    @Test
    public void testFindClosestNonSortedTemple() {
        apprenti.setX(c.getX());
        apprenti.setY(c.getY());
        System.out.println(apprenti.getX());
        System.out.println(apprenti.getY());
        Temple closestTemple = heuristiquePerso.findClosestNonSortedTemple(apprenti, temples);
        assertEquals(c, closestTemple);
    }

    @Test
    public void testCalculateDistance() {
        double distance = heuristiquePerso.calculateDistance(1, 1, 4, 5);
        assertEquals(7.0, distance);
    }
}