package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

class OptimalPersoTest {
    private OptimalPerso optimalPerso;
    private List<Temple> temples;
    private Apprenti apprenti;
    private Temple a;
    private Temple b;
    private Temple c;

    @BeforeEach
    public void setUp() {
        a = new Temple(1, 1, 1, 2);
        b = new Temple(2, 2, 2, 1);
        c = new Temple(5, 5, 3, 3);

        optimalPerso = new OptimalPerso();
        temples = new ArrayList<>();

        // Ajouter des temples de test
        temples.add(a);
        temples.add(b);
        temples.add(c);

        // Initialiser l'apprenti
        apprenti = new Apprenti(1, 1);
    }

    @Test
    public void testGeneratePathWithoutCrystal() {
        // L'apprenti devrait aller au temple le plus proche non trié
        List<Temple> plusProche = new ArrayList<>();
        plusProche.add(temples.get(0));

        List<Temple> chemin = optimalPerso.generatePath(temples, apprenti);

        assertEquals(plusProche, chemin);
    }

    @Test
    public void testGeneratePathWithCrystal() {
        // Donner un cristal de couleur 1 à l'apprenti
        apprenti.setColorCrystal(1);

        // L'apprenti doit aller au temple correspondant à la couleur de son cristal,
        // sauf si un échange avec un autre temple est plus optimal

        List<Temple> cheminOpti = new ArrayList<>();
        cheminOpti.add(temples.get(0)); // Le temple optimal est le a

        List<Temple> cheminActuel = optimalPerso.generatePath(temples, apprenti);

        assertEquals(cheminOpti, cheminActuel);
    }

    @Test
    public void testFindClosestNonSortedTemple() {
        Temple expectedTemple = temples.getFirst(); // Le temple le plus proche non trié est à (0,0)
        Temple actualTemple = optimalPerso.findClosestNonSortedTemple(apprenti, temples);
        assertEquals(expectedTemple, actualTemple, "Le temple non trié le plus proche devrait être celui à la position (0,0)");
    }


/**
    @Test
    public void testFindOptimalExchangeTemple() {
        apprenti.setColorCrystal(2);
        Temple targetTemple = temples.get(1);

        Temple expectedOptimalTemple = temples.get(1); // Le temple pour l'échange optimal le
        Temple actualOptimalTemple = optimalPerso.findOptimalExchangeTemple(apprenti, temples, targetTemple);

        assertEquals(expectedOptimalTemple, actualOptimalTemple, "Le temple pour l'échange optimal devrait être celui à la position (3,3)");
    }
**/
    @Test
    public void testFindTempleForCrystal() {
        Temple pairTemple = temples.get(0); // Le temple à la position (0,0) avec cristal de couleur 0
        Temple expectedTempleForCrystal = temples.get(1); // Le temple correspondant est à (2,2)
        Temple actualTempleForCrystal = optimalPerso.findTempleForCrystal(pairTemple, temples);

        assertEquals(expectedTempleForCrystal, actualTempleForCrystal, "Le temple correspondant au cristal devrait être celui à la position (2,2)");
    }
}