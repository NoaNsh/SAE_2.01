package model;

import view.GameCanvas;
import java.util.LinkedList;
import java.util.Queue;


public class Position {
    private static int nombreDePas = 0;
    private int abscisse;
    private int ordonnee;
    private Apprenti apprenti;



    public Position(Apprenti apprenti) {
        this.apprenti = apprenti;

        this.abscisse = apprenti.getX();
        this.ordonnee = apprenti.getY();

    }

    // Nouveau constructeur en utilisant x et y directement
    public Position(int abscisse, int ordonnee) {
        this.abscisse = abscisse;
        this.ordonnee = ordonnee;
    }

    public void moveApprenti(char direction, GameCanvas canvas, Apprenti apprenti) {
        // Obtenez la nouvelle position de l'apprenti en fonction de la direction
        int newX = apprenti.getX();
        int newY = apprenti.getY();
        int oldX = newX;
        int oldY = newY;

        switch (direction) {
            case 'Z':
                newY -= 1; // Déplacement vers le haut
                nombreDePas++;
                break;
            case 'Q':
                newX -= 1; // Déplacement vers la gauche
                nombreDePas++;
                break;
            case 'S':
                newY += 1; // Déplacement vers le bas
                nombreDePas++;
                break;
            case 'D':
                newX += 1; // Déplacement vers la droite
                nombreDePas++;
                break;
            case 'E':
                break;
        }



        // Redessiner l'apprenti et les cristaux sur le canvas
        canvas.dessinerMoveApprenti(direction, oldX, oldY ,newX, newY,1);

    }







    public static int getNombreDePas() {
        return nombreDePas;
    }

    public void setNombreDePas(int nmbrpas) {
        nombreDePas = nmbrpas;
    }


    public int getAbscisse() {
        return abscisse;
    }

    public void setAbscisse(int x) {
        this.abscisse = x;
    }

    public int getOrdonnee() {
        return ordonnee;
    }

    public void setOrdonnee(int y) {
        this.ordonnee = y;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Position position = (Position) obj;
        return abscisse == position.abscisse &&
                ordonnee == position.ordonnee;
    }

    @Override
    public String toString() {
        return "Position{" +
                "abscisse=" + abscisse +
                ", ordonnee=" + ordonnee +
                '}';
    }
}
