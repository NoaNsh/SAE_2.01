package model;

import javafx.scene.control.TextArea;

public class ZoneResultats extends TextArea {

    public ZoneResultats() {
        super();
        // Initialiser d'autres propriétés de la zone de résultats
    }
}

