package model;

import constants.Constants;

public class Apprenti implements Constants {
    private int x;
    private int y;
    private int colorCrystal;
    private String sprite_sheet_apprenti;

    public Apprenti(int x, int y) {
        this.x = APPRENTI_START_X;
        this.y = APPRENTI_START_Y;
        this.colorCrystal = APPRENTI_NO_CRYSTAL;
        this.sprite_sheet_apprenti = APPRENTI_SPRITE_SHEET;
    }

    // Getters et setters pour accéder aux attributs
    public Position getPosition() {
        return new Position(x, y);
    }
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getColorCrystal() {
        return colorCrystal;
    }

    public void setColorCrystal(int colorCrystal) {
        this.colorCrystal = colorCrystal;
    }
    public String getSprite_sheet_apprenti() { return sprite_sheet_apprenti; }

    public void setSprite_sheet_apprenti(String sprite_sheet_apprenti) { this.sprite_sheet_apprenti = sprite_sheet_apprenti; }
}
