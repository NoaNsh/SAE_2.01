package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Scenario {
    private List<Temple> temples;
    private String scenarioFile;
    public Scenario() {
        this.temples = new ArrayList<>();
    }

    public void fileLoader(String filepath) {
        try {
            Scanner scanner = new Scanner(new File(filepath));
            while (scanner.hasNextLine()) {
                String[] elements = scanner.nextLine().split(" ");
                int x = Integer.parseInt(elements[0]);
                int y = Integer.parseInt(elements[1]);
                int colorTemple = Integer.parseInt(elements[2]);
                int colorCrystal = Integer.parseInt(elements[3]);
                temples.add(new Temple(x, y, colorTemple, colorCrystal));
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearTemples() {
        temples.clear();
    }

    public List<Temple> getTemples() {
        return temples;
    }

    public void setTemples(List<Temple> temples) {
        this.temples = temples;
    }

    public String getScenarioFile() {
        return scenarioFile;
    }
}
