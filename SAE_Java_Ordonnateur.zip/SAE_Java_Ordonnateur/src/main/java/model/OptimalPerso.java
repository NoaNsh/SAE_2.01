package model;

import java.util.ArrayList;
import java.util.List;

public class OptimalPerso {

    public List<Temple> generatePath(List<Temple> temples, Apprenti apprenti) {
        List<Temple> path = new ArrayList<>();

        // Trouver le temple le plus proche de l'apprenti
        Temple closestTemple = findClosestNonSortedTemple(apprenti, temples);


        // Si l'apprenti n'a pas de cristal, aller au temple le plus proche non trié
        if (apprenti.getColorCrystal() == -1) {
            path.add(closestTemple);

        } else {
            // Sinon, aller au temple qui correspond à la couleur de son cristal
            Temple targetTemple = null;
            for (Temple temple : temples) {
                if (temple.getColorTemple() == apprenti.getColorCrystal()) {
                    targetTemple = temple;
                    break;
                }
            }



            // Vérifier s'il est possible d'effectuer un échange optimal
            Temple pairTemple = findOptimalExchangeTemple(apprenti, temples, targetTemple);


            if (pairTemple != null) {
                // Calculer la distance totale pour l'échange et comparer avec la distance pour aller au temple cible
                double totalDistance = calculateDistance(apprenti.getX(), apprenti.getY(), pairTemple.getX(), pairTemple.getY());
                double distanceToTargetTemple = calculateDistance(apprenti.getX(), apprenti.getY(), targetTemple.getX(), targetTemple.getY());


                if (totalDistance < distanceToTargetTemple  && 0.0 < totalDistance) {
                    // Effectuer l'échange s'il est plus efficace
                    path.add(pairTemple);
                    Temple exchangeTargetTemple = findTempleForCrystal(pairTemple, temples);
                    if (exchangeTargetTemple != null)
                        path.add(exchangeTargetTemple);
                        path.add(pairTemple);
                } else {
                    // Aller directement au temple cible
                    path.add(targetTemple);

                }
            }else {// Aller directement au temple cible
                path.add(targetTemple);

            }

        }
        return path;
    }

    public Temple findClosestNonSortedTemple(Apprenti apprenti, List<Temple> temples) {
        Temple closestTemple = null;
        double minDistance = Double.MAX_VALUE;

        for (Temple temple : temples) {
            // Vérifier si le temple n'est pas trié
            if (temple.getColorCrystal() != temple.getColorTemple()) {
                double distance = calculateDistance(apprenti.getX(), apprenti.getY(), temple.getX(), temple.getY());
                if (distance < minDistance) {
                    minDistance = distance;
                    closestTemple = temple;
                }
            }
        }

        return closestTemple;
    }

    public double calculateDistance(int x1, int y1, int x2, int y2) {
        return Math.abs(x2 - x1) + Math.abs(y2 - y1);
    }

    public Temple findOptimalExchangeTemple(Apprenti apprenti, List<Temple> temples, Temple targetTemple) {
        Temple optimalPairTemple = null;
        double minTotalDistance = calculateDistance(apprenti.getX(), apprenti.getY(), targetTemple.getX(), targetTemple.getY());
        List<Temple> optimalPairs = new ArrayList<>();

        for (Temple temple1 : temples) {
            for (Temple temple2 : temples) {

                if (temple1 != temple2 && temple1.getPosition() != targetTemple.getPosition() &&(temple1.getColorTemple() == temple2.getColorCrystal() && temple2.getColorTemple() == temple1.getColorCrystal())&&
                        (temple1.getColorCrystal() != temple1.getColorTemple() && temple2.getColorCrystal() != temple2.getColorTemple())) {
                    double totalDistance = calculateDistance(temple1.getX(), temple1.getY(), temple2.getX(), temple2.getY())+
                            calculateDistance(apprenti.getX(), apprenti.getY(), temple1.getX(), temple1.getY());
                    if (totalDistance < minTotalDistance) {
                        optimalPairs.add(temple1);

                    }
                }
            }
        }
        optimalPairTemple = findClosestNonSortedTemple(apprenti,optimalPairs);
        return optimalPairTemple;

    }
    public Temple findTempleForCrystal(Temple pairTemple, List<Temple> temples) {
        for (Temple temple : temples) {
            if (temple.getColorTemple() == pairTemple.getColorCrystal()) {
                return temple;
            }
        }
        return null;
    }
}
