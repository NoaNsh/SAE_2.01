package view;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.util.Duration;
import model.Apprenti;
import model.Temple;
import constants.Constants;

import java.awt.Point;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Timer;

public class GameCanvas extends Canvas implements Constants {
    private Image tilesetImage;
    private int[][] tiles; // Tableau pour stocker les indices des tuiles
    private Apprenti apprenti;
    private TilePane tilePane; // Déclaration de la variable tilePane
    private List<Temple> temples;
    GraphicsContext gc = getGraphicsContext2D();


    public GameCanvas(double width, double height, List<Temple> temples,Apprenti apprenti) {
        super(width, height);
        tilesetImage = new Image("file:imgs/img/Tileset_Grass.png");
        this.apprenti = apprenti;
        this.temples = temples; // Assigner la liste des temples

    }

    // Attribut pour stocker la carte générée aléatoirement
    private int[][] generatedMap;

    // Méthode pour dessiner la grille et stocker la carte générée aléatoirement
    public void dessinerGrille(int rows, int cols, double zoomFactor) {
        Random random = new Random();
        int centerX = (int) (getWidth() / 2); // Coordonnée X du point central
        int centerY = (int) (getHeight() / 2); // Coordonnée Y du point central

        // Initialiser le tableau pour stocker la carte générée aléatoirement
        generatedMap = new int[rows][cols];

        // Calculer les coordonnées de départ pour dessiner la grille autour du point central
        double startX = centerX - (cols / 2) * CELL_SIZE * zoomFactor;
        double startY = centerY - (rows / 2) * CELL_SIZE * zoomFactor;

        // Parcourir le tableau de tuiles et dessiner chaque tuile à la position correspondante
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int tileIndex = random.nextInt(61); // Valeur aléatoire entre 0 et 61 (indice des tuiles)
                generatedMap[row][col] = tileIndex; // Stocker l'indice de la tuile dans le tableau
                int sourceX = (tileIndex % 8) * CELL_SIZE; // Coordonnée X de la tuile dans l'image
                int sourceY = (tileIndex / 8) * CELL_SIZE; // Coordonnée Y de la tuile dans l'image
                double targetX = startX + (int) (col * CELL_SIZE * zoomFactor); // Position X de la tuile sur le canvas
                double targetY = startY + (int) (row * CELL_SIZE * zoomFactor); // Position Y de la tuile sur le canvas
                int targetWidth = (int) (CELL_SIZE * zoomFactor); // Largeur de la tuile sur le canvas
                int targetHeight = (int) (CELL_SIZE * zoomFactor); // Hauteur de la tuile sur le canvas
                gc.drawImage(tilesetImage, sourceX, sourceY, CELL_SIZE, CELL_SIZE, targetX, targetY, targetWidth, targetHeight);
            }
        }
    }

    // Méthode pour réinitialiser la grille sans le personnage et les cristaux en utilisant la carte stockée
    public void resetGrid(int rows, int cols, double zoomFactor) {

        if (generatedMap != null) {
            int centerX = (int) (getWidth() / 2); // Coordonnée X du point central
            int centerY = (int) (getHeight() / 2); // Coordonnée Y du point central

            // Calculer les coordonnées de départ pour dessiner la grille autour du point central
            double startX = centerX - (cols / 2) * CELL_SIZE * zoomFactor;
            double startY = centerY - (rows / 2) * CELL_SIZE * zoomFactor;

            // Parcourir le tableau de tuiles et dessiner chaque tuile à la position correspondante en utilisant la carte stockée
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    int tileIndex = generatedMap[row][col]; // Récupérer l'indice de la tuile à partir de la carte stockée
                    int sourceX = (tileIndex % 8) * CELL_SIZE; // Coordonnée X de la tuile dans l'image
                    int sourceY = (tileIndex / 8) * CELL_SIZE; // Coordonnée Y de la tuile dans l'image
                    double targetX = startX + (int) (col * CELL_SIZE * zoomFactor); // Position X de la tuile sur le canvas
                    double targetY = startY + (int) (row * CELL_SIZE * zoomFactor); // Position Y de la tuile sur le canvas
                    int targetWidth = (int) (CELL_SIZE * zoomFactor); // Largeur de la tuile sur le canvas
                    int targetHeight = (int) (CELL_SIZE * zoomFactor); // Hauteur de la tuile sur le canvas
                    gc.drawImage(tilesetImage, sourceX, sourceY, CELL_SIZE, CELL_SIZE, targetX, targetY, targetWidth, targetHeight);
                }
            }
        }

    }






    // Méthode pour dessiner les temples
    public void dessinerTemples(List<Temple> temples, double zoomFactor) {

        // Charger le sprite sheet des temples
        Image spriteSheet = new Image("file:imgs/img/color_temple_sprite_sheet.png");
        Image templeShadow = new Image("file:imgs/img/Temple_Shadow.png");


        for (Temple temple : temples) {
            int x = temple.getX(); // Récupérer la position X du temple dans la grille
            int y = temple.getY(); // Récupérer la position Y du temple dans la grille

            // Convertir les coordonnées de la grille en pixels
            Point pixelCoordinates = convertGridCoordinatesToPixels(x, y,zoomFactor);

            int color = temple.getColorTemple();

            // Calculer les coordonnées source dans le sprite sheet en fonction de la couleur du temple
            int sourceX = (color-1) * TEMPLE_SIZE_X; // La largeur de chaque temple est la même dans le sprite sheet

            // Dessiner l'image du temple à l'emplacement spécifié avec le facteur de zoom
            int targetWidth = (int) (TEMPLE_SIZE_X * zoomFactor);
            int targetHeight = (int) (TEMPLE_SIZE_Y * zoomFactor);


            gc.drawImage(templeShadow, pixelCoordinates.x-CELL_SIZE, pixelCoordinates.y-20, TEMPLE_SIZE_X+2 * zoomFactor, targetHeight);
            gc.drawImage(spriteSheet, sourceX, 0, TEMPLE_SIZE_X, TEMPLE_SIZE_Y, pixelCoordinates.x-CELL_SIZE, pixelCoordinates.y-20, targetWidth, targetHeight);

        }
    }
    public void dessinerbackground(){

    }



    // Méthode pour dessiner les cristaux
    public void dessinerCristaux(List<Temple> temples, double zoomFactor) {

        // Parcourir chaque temple pour dessiner les cristaux correspondants
        for (Temple temple : temples) {
            int templeX = temple.getX();
            int templeY = temple.getY();
            int templeColor = temple.getColorTemple();
            int crystalColor = temple.getColorCrystal();

            // Vérifier si les couleurs du temple et du cristal correspondent
            if (templeColor == crystalColor) {
                // Dessiner le cristal animé
                String crystalAnimationFileName = getCrystalAnimationFileName(templeColor);
                Image crystalAnimation = new Image("file:imgs/img/" + crystalAnimationFileName);
                ImageView imageView = new ImageView(crystalAnimation);
                Point pixelCoordinates = convertGridCoordinatesToPixels(templeX, templeY, zoomFactor);
                imageView.setX(pixelCoordinates.x);
                imageView.setY(pixelCoordinates.y);
                imageView.setFitWidth(CELL_SIZE * zoomFactor);
                imageView.setFitHeight(CELL_SIZE * zoomFactor);
                // Récupérer la scène parente
                Scene scene = getScene();
                if (scene != null) {
                    BorderPane root = (BorderPane) scene.getRoot();
                    root.getChildren().add(imageView);
            }} else {
                // Dessiner le cristal non animé
                String crystalFileName = getCrystalFileName(crystalColor);
                Image crystal = new Image("file:imgs/img/" + crystalFileName);
                ImageView imageView = new ImageView(crystal);
                Point pixelCoordinates = convertGridCoordinatesToPixels(templeX, templeY, zoomFactor);
                imageView.setX(pixelCoordinates.x);
                imageView.setY(pixelCoordinates.y);
                imageView.setFitWidth(CELL_SIZE * zoomFactor);
                imageView.setFitHeight(CELL_SIZE * zoomFactor);
                // Récupérer la scène parente
                Scene scene = getScene();
                if (scene != null) {
                    BorderPane root = (BorderPane ) scene.getRoot(); // Ou un autre type Parent approprié
                    root.getChildren().add(imageView);
                }
            }
        }
    }

    // Méthode pour obtenir le nom de fichier du cristal animé en fonction de sa couleur
    private String getCrystalAnimationFileName(int color) {
        switch (color) {
            case 1: return "blue_crystal_animated.gif";
            case 2: return "purple_crystal_animated.gif";
            case 3: return "green_crystal_animated.gif";
            case 4: return "yellow_crystal_animated.gif";
            case 5: return "cyan_crystal_animated.gif";
            case 6: return "light_crystal_animated.gif";
            case 7: return "red_crystal_animated.gif";
            case 8: return "orange_crystal_animated.gif";
            case 9: return "dark_crystal_animated.gif";
            default: return "";
        }
    }

    // Méthode pour obtenir le nom de fichier du cristal statique en fonction de sa couleur
    private String getCrystalFileName(int color) {
        switch (color) {
            case 1: return "blue_crystal.gif";
            case 2: return "purple_crystal.gif";
            case 3: return "green_crystal.gif";
            case 4: return "yellow_crystal.gif";
            case 5: return "cyan_crystal.gif";
            case 6: return "light_crystal.gif";
            case 7: return "red_crystal.gif";
            case 8: return "orange_crystal.gif";
            case 9: return "dark_crystal.gif";
            default: return "";
        }
    }




    // Méthode pour supprimer les cristaux du canvas
    public void supprimerCristaux(List<Temple> temples, double zoomFactor) {
        // Récupérer la scène parente
        Scene scene = getScene();
        if (scene != null) {
            Pane root = (Pane) scene.getRoot(); // Ou un autre type Parent approprié
            // Parcourir chaque temple pour supprimer les cristaux correspondants
            for (Temple temple : temples) {
                int templeX = temple.getX();
                int templeY = temple.getY();
                // Calculer les coordonnées du temple dans le canvas
                Point pixelCoordinates = convertGridCoordinatesToPixels(templeX, templeY, zoomFactor);
                // Parcourir les enfants du root pour trouver et supprimer les cristaux
                root.getChildren().removeIf(node -> {
                    if (node instanceof ImageView) {
                        ImageView imageView = (ImageView) node;
                        return imageView.getX() == pixelCoordinates.x && imageView.getY() == pixelCoordinates.y;
                    }
                    return false;
                });
            }
        }
    }



    // Méthode pour dessiner l'apprenti
    public void dessinerApprenti(Apprenti apprenti, double zoomFactor) {

        int x = apprenti.getX(); // Récupérer la position X de l'apprenti dans la grille
        int y = apprenti.getY(); // Récupérer la position Y de l'apprenti dans la grille

        // Convertir les coordonnées de la grille en pixels
        Point pixelCoordinates = convertGridCoordinatesToPixels(x, y,zoomFactor );

        // Charger l'image de l'apprenti
        Image playerImage = new Image("file:imgs/img/Apprenti.png");

        // Dessiner l'image à la position spécifiée avec le facteur de zoom
        int targetWidth = (int) (CELL_SIZE * 2 * zoomFactor*2);
        int targetHeight = (int) (CELL_SIZE * zoomFactor*2);

        gc.drawImage(playerImage, pixelCoordinates.x-SPRITE_SIZE_X/4, pixelCoordinates.y-(CELL_SIZE-CELL_SIZE/4), targetWidth, targetHeight);

    }


    public void dessinerMoveApprenti(char direction, int oldX,int oldY ,int x, int y, double zoomFactor) {


        int targetWidth = (int) (CELL_SIZE * 2 * zoomFactor * 2);
        int targetHeight = (int) (CELL_SIZE * zoomFactor * 2);
        int speed = SPEED_ANIMATION; //vitesse de l'animation



        final int spriteY;
        switch (direction) {
            case DIRECTION_UP: spriteY = SPRITE_SIZE_Y * 3; break; // Haut
            case DIRECTION_LEFT: spriteY = 0; break; // Gauche
            case DIRECTION_DOWN: spriteY = SPRITE_SIZE_Y * 2; break; // Bas
            case DIRECTION_RIGHT: spriteY = SPRITE_SIZE_Y; break; // Droite
            case SWITCH_CRYSTAL: // Action spéciale (échange de cristaux)
                switchCrystal(x, y);
                supprimerCristaux(temples, zoomFactor);
                dessinerCristaux(temples, zoomFactor);
                spriteY = 0;
                break;
            default: spriteY = 0; // Default
        }
        getApprentiSpriteSheetPath(apprenti.getColorCrystal());
        String spriteSheetPath = apprenti.getSprite_sheet_apprenti();
        Image moveAnimation = new Image("file:imgs/img/" + spriteSheetPath);

        final int startX = oldX;
        final int startY = oldY;
        final int endX = x;
        final int endY = y;


        Timeline timeline = new Timeline();
        timeline.setCycleCount(1);

        for (int i = 0; i < 3; i++) {
            final int spriteX = i * SPRITE_SIZE_X; // Animation des frames (1/3, 2/3, 0)
            double t = (i + 1) / 3.0;

            final int offsetX = (int) ((endX - startX) * CELL_SIZE * t);
            final int offsetY = (int) ((endY - startY) * CELL_SIZE * t);

            final Point startPixelCoordinates = convertGridCoordinatesToPixels(startX, startY, zoomFactor);

            KeyFrame keyFrame = new KeyFrame(Duration.millis(speed * (i + 1)), event -> {
                gc.clearRect(0, 0, getWidth(), getHeight());
                resetGrid(GRID_WIDTH, GRID_HEIGHT, zoomFactor);
                dessinerTemples(temples, zoomFactor);
                gc.drawImage(moveAnimation, spriteX, spriteY, SPRITE_SIZE_X, SPRITE_SIZE_Y,
                        startPixelCoordinates.x + offsetX - SPRITE_SIZE_X / 4,
                        startPixelCoordinates.y + offsetY - (CELL_SIZE - CELL_SIZE / 4),
                        targetWidth, targetHeight);
            });

            timeline.getKeyFrames().add(keyFrame);
        }

        timeline.setOnFinished(event -> {
            apprenti.setX(endX);
            apprenti.setY(endY);
            final Point pixelCoordinates = convertGridCoordinatesToPixels(endX, endY, zoomFactor);
            gc.clearRect(0, 0, getWidth(), getHeight());
            resetGrid(GRID_WIDTH, GRID_HEIGHT, zoomFactor);
            dessinerTemples(temples, zoomFactor);
            gc.drawImage(moveAnimation, 0, spriteY, SPRITE_SIZE_X, SPRITE_SIZE_Y,
                    pixelCoordinates.x - SPRITE_SIZE_X / 4, pixelCoordinates.y - (CELL_SIZE - CELL_SIZE / 4), targetWidth, targetHeight);
        });

        timeline.play();

    }






    // Méthode pour obtenir le chemin du sprite sheet de l'apprenti en fonction de la couleur du cristal
    private void getApprentiSpriteSheetPath(int crystalColor) {
        switch (crystalColor) {
            case 1:
                apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_blue.png");
                break;
            case 2: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_purple.png");
                break;
            case 3: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_green.png");
                break;
            case 4: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_yellow.png");
                break;
            case 5: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_cyan.png");
                break;
            case 6: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_light.png");
                break;
            case 7: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_red.png");
                break;
            case 8: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_orange.png");
                break;
            case 9: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti_dark.png");
                break;
            default: apprenti.setSprite_sheet_apprenti("sprite_sheet_apprenti.png"); // Sprite par défaut si la couleur du cristal est -1 donc il n'y en a pas
                break;

        }
    }

    private void switchCrystal(int x, int y) {
        // Récupérer le temple à la position spécifiée
        Temple temple = getTempleAtPosition(x, y);

        if (temple != null) {

            int templeColor = temple.getColorCrystal();

            // Vérifier si l'apprenti n'a pas de cristal
            if (apprenti.getColorCrystal() == Temple.TEMPLE_EMPTY) {

                // L'apprenti prend le cristal du temple
                apprenti.setColorCrystal(templeColor);
                temple.setColorCrystal(Temple.TEMPLE_EMPTY);
            } else {

                // L'apprenti échange son cristal avec celui du temple
                int apprentiColor = apprenti.getColorCrystal();
                apprenti.setColorCrystal(templeColor);
                temple.setColorCrystal(apprentiColor);

            }
        }
    }



    // Méthode pour obtenir le temple à une position spécifiée
    private Temple getTempleAtPosition(int x, int y) {

        for (Temple temple : temples) {

            if (temple.getX() == x && temple.getY() == y) {
                return temple;
            }
        }
        return null;
    }



    // Méthode pour convertir les coordonnées de la grille en pixels
    private Point convertGridCoordinatesToPixels(int gridX, int gridY, double zoomFactor) {
        int centerX = (int) (getWidth() / 2); // Coordonnée X du centre de l'écran
        int centerY = (int) (getHeight() / 2); // Coordonnée Y du centre de l'écran


        // Calculer les coordonnées en pixels du point correspondant sur la grille
        int pixelX =  (int) (centerX + CELL_SIZE * gridX *zoomFactor );
        int pixelY =  (int) (centerY + CELL_SIZE * gridY *zoomFactor);

        return new Point(pixelX, pixelY);
    }

    // Méthode inverse pour convertir les coordonnées en pixels en coordonnées de la grille
    public Point convertPixelsToGridCoordinates(double pixelX, double pixelY, double zoomFactor) {
        int centerX = (int) (getWidth() / 2); // Coordonnée X du centre de l'écran
        int centerY = (int) (getHeight() / 2); // Coordonnée Y du centre de l'écran

        // Calculer les coordonnées de la grille à partir des pixels
        int gridX = (int) Math.round((pixelX - centerX) / (CELL_SIZE * zoomFactor)-0.49); //0,49 pour arrondir au plus bas
        int gridY = (int) Math.round((pixelY - centerY) / (CELL_SIZE * zoomFactor)-0.49);


        return new Point(gridX, gridY);
    }


    public void clear() {
        gc.clearRect(0, 0, getWidth(), getHeight());

    }
}
