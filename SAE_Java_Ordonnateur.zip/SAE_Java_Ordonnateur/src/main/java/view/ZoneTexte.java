package view;

import javafx.scene.control.TextArea;

public class ZoneTexte extends TextArea {

    public ZoneTexte() {
        // Initialisez la zone de texte ici
    }
}

