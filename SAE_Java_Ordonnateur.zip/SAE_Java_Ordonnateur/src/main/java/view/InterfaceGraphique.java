package view;

import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class InterfaceGraphique {
    private GameCanvas gameCanvas;
    private Menu menu;


    public InterfaceGraphique(GameCanvas gameCanvas) {
        this.gameCanvas = gameCanvas;
        this.menu = new Menu();

    }

    public void show(Stage primaryStage) {
        BorderPane root = new BorderPane();
        root.setCenter(gameCanvas);
        root.setRight(menu);


        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("L'Apprenti Ordonnateur");
        primaryStage.show();
    }

    public Menu getMenu() {
        return menu;
    }
}
