package view;

import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.geometry.Insets;
import model.Position;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Menu extends VBox {

    private ComboBox<String> scenarioComboBox;
    public ComboBox<String> algorithmComboBox;
    private Label deplacementsLabel;
    private Button resetButton; // Ajout du bouton reset
    private ChangeScenarioListener changeScenarioListener;
    private ChangeAlgorithmListener changeAlgorithmListener;
    private ResetListener resetListener; // Ajout du listener de reset

    public Menu() {
        scenarioComboBox = new ComboBox<>();
        algorithmComboBox = new ComboBox<>();
        loadScenarioFiles();
        loadAlgorithms();

        scenarioComboBox.setOnAction(e -> changerScenario(scenarioComboBox.getValue()));
        algorithmComboBox.setOnAction(e -> changerAlgorithm(algorithmComboBox.getValue()));

        deplacementsLabel = new Label("Déplacements: " + Position.getNombreDePas());
        deplacementsLabel.setFont(new Font("Helvetica", 16));

        resetButton = new Button("Reset");
        resetButton.setOnAction(e -> {
            if (resetListener != null) {
                resetListener.onReset(); // Appel de la méthode reset du GameController
            }
        });

        setSpacing(20);
        setPadding(new Insets(10));
        getChildren().addAll(deplacementsLabel, scenarioComboBox, algorithmComboBox, resetButton);

        // Ajouter le fichier CSS
        File cssFile = new File("css/menu.css");
        getStylesheets().add(cssFile.toURI().toString());
        getStyleClass().add("root");
    }

    private void loadScenarioFiles() {
        File folder = new File("File");
        List<String> scenarios = Arrays.stream(folder.listFiles((dir, name) -> name.endsWith(".txt")))
                .map(File::getName)
                .collect(Collectors.toList());
        scenarioComboBox.getItems().addAll(scenarios);
        if (!scenarios.isEmpty()) {
            scenarioComboBox.setValue("Scénario:"); // Sélectionner le premier scénario par défaut
        }
    }

    public void loadAlgorithms() {
        List<String> algorithms = Arrays.asList("Tri à bulle", "Tri par sélection", "Heuristique", "Optimal");
        algorithmComboBox.getItems().addAll(algorithms);
        if (!algorithms.isEmpty()) {
            algorithmComboBox.setValue("Algorithme:"); // Sélectionner le premier algorithme par défaut
        }
    }

    private void changerScenario(String scenario) {
        if (changeScenarioListener != null) {
            changeScenarioListener.onScenarioChange("File/" + scenario);
        }
    }

    private void changerAlgorithm(String algorithm) {
        if (changeAlgorithmListener != null) {
            changeAlgorithmListener.onAlgorithmChange(algorithm);
        }
    }

    public void setChangeScenarioListener(ChangeScenarioListener listener) {
        this.changeScenarioListener = listener;
    }

    public void setChangeAlgorithmListener(ChangeAlgorithmListener listener) {
        this.changeAlgorithmListener = listener;
    }

    public void setResetListener(ResetListener resetListener) {
        this.resetListener = resetListener;
    }

    public void updateDeplacements() {
        deplacementsLabel.setText("Déplacements: " + Position.getNombreDePas());
    }

    public String getScenarioFile() {
        String selectedScenario = scenarioComboBox.getValue();
        if (selectedScenario != null && !selectedScenario.equals("Scénario:")) {
            return "File/" + selectedScenario;
        }
        return null;
    }

    public interface ChangeScenarioListener {
        void onScenarioChange(String scenarioFile);
    }

    public interface ChangeAlgorithmListener {
        void onAlgorithmChange(String algorithm);
    }

    public interface ResetListener {
        void onReset();
    }
}
