package controller;

import javafx.application.Platform;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import model.*;
import view.GameCanvas;
import view.Menu;
import java.awt.Point;
import java.util.List;
import constants.Constants;

public class GameController implements Constants {
    private GameCanvas gameCanvas;
    private Position position;
    private Apprenti apprenti;
    private Menu menu;
    private Scenario scenario;
    private volatile boolean isMoving;
    private volatile boolean running;

    public GameController(GameCanvas gameCanvas, Position position, Apprenti apprenti, Menu menu, Scenario scenario) {
        this.gameCanvas = gameCanvas;
        this.position = position;
        this.apprenti = apprenti;
        this.menu = menu;
        this.scenario = scenario;
        this.menu.setChangeScenarioListener(this::loadScenario);
        this.menu.setChangeAlgorithmListener(this::loadAlgorithm);
        this.menu.setResetListener(this::reset);

        this.isMoving = false;
        this.running = true;
        setupMouseEvents();
    }

    private void setupMouseEvents() {
        gameCanvas.setOnMouseClicked(event -> {
            Point gridCoordinates = gameCanvas.convertPixelsToGridCoordinates(event.getX(), event.getY(), ZOOM_FACTOR);

            // Convertir les coordonnées de la souris en coordonnées de la grille
            int targetX = gridCoordinates.x;
            int targetY = gridCoordinates.y;

            // Lancer un thread pour déplacer l'apprenti vers la position cible
            new Thread(() -> moveApprentiToTarget(targetX, targetY)).start();
        });
    }

    private void moveApprentiToTarget(int targetX, int targetY) {
        if (isMoving || !running) return;  // Si l'apprenti est déjà en déplacement ou si la balise running est false, ignorer la nouvelle commande

        isMoving = true;  // Indiquer que l'apprenti est en déplacement
        int apprentiX = apprenti.getX();
        int apprentiY = apprenti.getY();

        // Déplacement d'abord sur l'axe X
        while (apprentiX != targetX && running) {
            if (apprentiX < targetX) {
                apprentiX++;
                Platform.runLater(() -> position.moveApprenti(DIRECTION_RIGHT, gameCanvas, apprenti));
            } else if (apprentiX > targetX) {
                apprentiX--;
                Platform.runLater(() -> position.moveApprenti(DIRECTION_LEFT, gameCanvas, apprenti));
            }
            final int finalApprentiX = apprentiX;  // Capture pour le lambda
            final int finalApprentiY = apprentiY;  // Capture pour le lambda
            Platform.runLater(() -> {
                apprenti.setX(finalApprentiX);
                apprenti.setY(finalApprentiY);
                menu.updateDeplacements();  // Mise à jour du nombre de déplacements
            });
            try {
                Thread.sleep(100);  // Ajustez la vitesse si nécessaire
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Puis déplacement sur l'axe Y
        while (apprentiY != targetY && running) {
            if (apprentiY < targetY) {
                apprentiY++;
                Platform.runLater(() -> position.moveApprenti(DIRECTION_DOWN, gameCanvas, apprenti));
            } else if (apprentiY > targetY) {
                apprentiY--;
                Platform.runLater(() -> position.moveApprenti(DIRECTION_UP, gameCanvas, apprenti));
            }
            final int finalApprentiX = apprentiX;  // Capture pour le lambda
            final int finalApprentiY = apprentiY;  // Capture pour le lambda
            Platform.runLater(() -> {
                apprenti.setX(finalApprentiX);
                apprenti.setY(finalApprentiY);
                menu.updateDeplacements();  // Mise à jour du nombre de déplacements
            });
            try {
                Thread.sleep(MOVE_SLEEP_DURATION);  // Ajustez la vitesse si nécessaire
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Une fois arrivé, envoyer la touche 'E' pour échanger les cristaux
        if (running) {
            Platform.runLater(() -> {
                position.moveApprenti(SWITCH_CRYSTAL, gameCanvas, apprenti);
                menu.updateDeplacements();  // Mise à jour du nombre de déplacements
            });
        }

        isMoving = false;  // Indiquer que l'apprenti a terminé son déplacement
    }

    public void handleInput(KeyEvent event) {
        if (isMoving || !running) return;  // Si l'apprenti est déjà en déplacement ou si la balise running est false, ignorer la nouvelle commande

        KeyCode code = event.getCode();
        isMoving = true;  // Indiquer que l'apprenti est en déplacement
        if (code == KeyCode.UP || code == KeyCode.Z || code == KeyCode.W) {
            position.moveApprenti(DIRECTION_UP, gameCanvas, apprenti);
        } else if (code == KeyCode.DOWN || code == KeyCode.S) {
            position.moveApprenti(DIRECTION_DOWN, gameCanvas, apprenti);
        } else if (code == KeyCode.LEFT || code == KeyCode.Q || code == KeyCode.A) {
            position.moveApprenti(DIRECTION_LEFT, gameCanvas, apprenti);
        } else if (code == KeyCode.RIGHT || code == KeyCode.D) {
            position.moveApprenti(DIRECTION_RIGHT, gameCanvas, apprenti);
        } else if (code == KeyCode.E) {
            position.moveApprenti(SWITCH_CRYSTAL, gameCanvas, apprenti);
        }
        Platform.runLater(() -> menu.updateDeplacements());  // Mise à jour du nombre de déplacements

        // Attendre que l'animation soit terminée avant de remettre isMoving à false
        new Thread(() -> {
            try {
                Thread.sleep(MOVE_SLEEP_DURATION);  // Ajustez cette valeur en fonction de la durée de l'animation
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            isMoving = false;  // Indiquer que l'apprenti a terminé son déplacement
        }).start();
    }

    private void loadScenario(String scenarioFile) {
        Platform.runLater(() -> {
            gameCanvas.supprimerCristaux(scenario.getTemples(), ZOOM_FACTOR);
            scenario.clearTemples(); // Vider la liste des temples
            gameCanvas.clear();
            apprenti.setX(APPRENTI_START_X);
            apprenti.setY(APPRENTI_START_Y);
            apprenti.setColorCrystal(APPRENTI_NO_CRYSTAL);
            position.setNombreDePas(0);
            menu.updateDeplacements();

            scenario.fileLoader(scenarioFile); // Charger le nouveau scénario
            gameCanvas.dessinerGrille(GRID_WIDTH, GRID_HEIGHT, ZOOM_FACTOR); // Redessiner la grille
            gameCanvas.dessinerTemples(scenario.getTemples(), ZOOM_FACTOR); // Redessiner les temples
            gameCanvas.dessinerCristaux(scenario.getTemples(), ZOOM_FACTOR); // Redessiner les cristaux
            gameCanvas.dessinerApprenti(apprenti, ZOOM_FACTOR); // Redessiner l'apprenti à la nouvelle position
        });
    }

    private void loadAlgorithm(String algorithm) {
        if ("Tri à bulle".equals(algorithm)) {
            BubbleSortAlgo();
        } else if ("Tri par sélection".equals(algorithm)) {
            SelectionSortAlgo();
        } else if ("Heuristique".equals(algorithm)) {
            HeuristicPersoSortAlgo();
        } else if ("Optimal".equals(algorithm)) {
            OptimalPersoSortAlgo();
        }
    }

    private void HeuristicPersoSortAlgo() {
        System.out.println(HEURISTIC_SORT_MESSAGE);

        new Thread(() -> {
            HeuristiquePerso heuristiquePerso = new HeuristiquePerso();
            boolean sorted = false;
            while (!sorted && running) {
                try {
                    Thread.sleep(ALGORITHM_SLEEP_DURATION); // Attendre une courte période avant de vérifier à nouveau
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                List<Temple> path = heuristiquePerso.generatePath(scenario.getTemples(), apprenti);
                if (!path.isEmpty()) {
                    for (Temple temple : path) {
                        if (!running) return;
                        waitForApprentiToMove(temple.getX(), temple.getY());
                    }
                }
                sorted = checkIfAllCrystalsSorted(scenario.getTemples());
            }
        }).start();
    }

    private void OptimalPersoSortAlgo() {
        System.out.println(OPTIMAL_SORT_MESSAGE);

        new Thread(() -> {
            OptimalPerso optimalPerso = new OptimalPerso();
            boolean sorted = false;
            while (!sorted && running) {

                List<Temple> path = optimalPerso.generatePath(scenario.getTemples(),apprenti);
                if (!path.isEmpty()) {
                    for (Temple temple : path) {
                        if (!running) return;
                        waitForApprentiToMove(temple.getX(), temple.getY());
                        try {
                            Thread.sleep(ALGORITHM_SLEEP_DURATION); // Attendre une courte période avant de vérifier à nouveau
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                sorted = checkIfAllCrystalsSorted(scenario.getTemples());
            }
        }).start();
    }



    private void BubbleSortAlgo() {
        System.out.println(BUBBLE_SORT_MESSAGE);

        // Créer un nouveau thread pour éviter de bloquer l'interface utilisateur
        new Thread(() -> {
            BubbleSort bubbleSortAlgorithm = new BubbleSort(scenario.getTemples(), apprenti);
            boolean sorted = false;
            while (!sorted) {
                // Générer le chemin optimal pour l'apprenti
                List<Position> path = bubbleSortAlgorithm.triBulles();
                System.out.println(path);
                // Déplacer l'apprenti vers chaque temple du chemin
                for (Position position : path) {
                    waitForApprentiToMove(position.getAbscisse(), position.getOrdonnee());
                    try {
                        Thread.sleep(ALGORITHM_SLEEP_DURATION); // Attendre une courte période avant de vérifier à nouveau
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    // Vérifier si tous les temples sont triés
                    sorted = checkIfAllCrystalsSorted(scenario.getTemples());
                    if (sorted) {
                        break;
                    }
                }
            }
        }).start();
    }

    private void SelectionSortAlgo() {
        System.out.println(SELECTION_SORT_MESSAGE);

        // Créer un nouveau thread pour éviter de bloquer l'interface utilisateur
        new Thread(() -> {
            SelectionSort selectionSortAlgorithm = new SelectionSort(scenario.getTemples(), apprenti);
            boolean sorted = false;
            while (!sorted) {
                // Générer le chemin optimal pour l'apprenti
                List<Position> path = selectionSortAlgorithm.triSelection();
                // Déplacer l'apprenti vers chaque temple du chemin
                for (Position position : path) {
                    waitForApprentiToMove(position.getAbscisse(), position.getOrdonnee());
                    try {
                        Thread.sleep(ALGORITHM_SLEEP_DURATION); // Attendre une courte période avant de vérifier à nouveau
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    // Vérifier si tous les temples sont triés
                    sorted = checkIfAllCrystalsSorted(scenario.getTemples());
                    if (sorted) {
                        break;
                    }
                }
            }
        }).start();
    }

    private void waitForApprentiToMove(int targetX, int targetY) {
        moveApprentiToTarget(targetX, targetY);
        while (isMoving && running) {
            try {
                Thread.sleep(WAIT_FOR_MOVE_SLEEP_DURATION);  // Attendre que le mouvement soit terminé
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean checkIfAllCrystalsSorted(List<Temple> temples) {
        for (Temple temple : temples) {
            if (temple.getColorCrystal() != temple.getColorTemple()) {
                return false;
            }
        }
        return true;
    }

    private void reset() {
        running = false; // Arrêter tous les threads en cours
        isMoving = false; // Arrêter tout déplacement en cours

        // Attendre une courte période pour s'assurer que tous les threads sont arrêtés
        try {
            Thread.sleep(RESET_SLEEP_DURATION);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        menu.algorithmComboBox.setValue(DEFAULT_ALGORITHM_COMBOBOX_VALUE); // Réinitialiser la combobox des algorithmes //ne fonctionne mystérieusement pas


        running = true;
        loadScenario(menu.getScenarioFile()); // Recharger le scénario en cours

    }
}
