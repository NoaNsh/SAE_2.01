package constants;

public interface Constants {
    // Main constants
    int CANVAS_WIDTH = 1750;
    int CANVAS_HEIGHT = 1080;
    String SCENARIO_FILE = "File/scenarioTest.txt";
    double ZOOM_FACTOR = 1;
    // Grid size
    int GRID_WIDTH = 33;
    int GRID_HEIGHT = 33;

    // Apprenti constants
    int APPRENTI_START_X = 0;
    int APPRENTI_START_Y = 0;
    int APPRENTI_NO_CRYSTAL = -1;
    String APPRENTI_SPRITE_SHEET = "sprite_sheet_apprenti.png";

    // Temple constants
    int TEMPLE_EMPTY = -1;


    // Constants for directions
    public static final char DIRECTION_UP = 'Z';
    public static final char DIRECTION_DOWN = 'S';
    public static final char DIRECTION_LEFT = 'Q';
    public static final char DIRECTION_RIGHT = 'D';
    public static final char SWITCH_CRYSTAL = 'E';

    // Constants for thread sleep durations
    public static final int MOVE_SLEEP_DURATION = 100;
    public static final int ALGORITHM_SLEEP_DURATION = 500;
    public static final int WAIT_FOR_MOVE_SLEEP_DURATION = 2000;
    public static final int RESET_SLEEP_DURATION = 3000;

    // Constants for messages
    public static final String BUBBLE_SORT_MESSAGE = "Lancement de l'algorithme de tri par bulles";
    public static final String SELECTION_SORT_MESSAGE = "Lancement de l'algorithme de tri par sélection";
    public static final String HEURISTIC_SORT_MESSAGE = "Lancement de l'algorithme heuristique personnalisé";
    public static final String OPTIMAL_SORT_MESSAGE = "Lancement de l'algorithme de tri optimal";


    // Algorithm ComboBox default value
    public static final String DEFAULT_ALGORITHM_COMBOBOX_VALUE = "Algorithme:";

    //GameCanvas
    int CELL_SIZE = 32; // Taille de chaque case en pixels
    int TEMPLE_SIZE_X = 94; // Taille de chaque temple dans le sprite sheet
    int TEMPLE_SIZE_Y = 72; // Taille de chaque temple dans le sprite sheet
    int SPRITE_SIZE_X = 204; // Largeur d'un sprite dans l'animation
    int SPRITE_SIZE_Y = 112; // Hauteur d'un sprite dans l'animation
    int SPEED_ANIMATION = 22; // Vitesse de l'animation
}
